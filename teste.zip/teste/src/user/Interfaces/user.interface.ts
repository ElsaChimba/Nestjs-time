
export interface UserInterface {
    id: string;
    username: string;
    password: string;
    salt: string;
    firstName: string;
    lastName: string;
    email: string;
    active: boolean;
  }
  
  