export class UserUpdatableInterface {
    firstName?:string;
    lastName?:string;
    active?:boolean;
}